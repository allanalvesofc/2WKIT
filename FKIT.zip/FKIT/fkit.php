<?php

require 'fmgr.php';
require 'ntfy.php';
require 'zdata.php';
require 'funcs.php';


?>